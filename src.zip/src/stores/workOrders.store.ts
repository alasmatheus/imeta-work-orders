import { create } from "zustand";

import { mapRealmWorkOrder } from "@/data/realm/mappers";
import { getRealm } from "@/data/realm/realm";
import { LocalWorkOrder } from "@/domain/workOrders/localWorkOrder";
import {
  CreateWorkOrderPayload,
  UpdateWorkOrderPayload,
} from "@/domain/workOrders/payloads";
import {
  fetchAndCacheWorkOrderById,
  getLocalWorkOrderById,
  getLocalWorkOrders,
} from "@/services/workOrders.service";

type WorkOrdersStore = {
  items: LocalWorkOrder[];
  selectedItem: LocalWorkOrder | null;
  loading: boolean;
  error: string | null;

  loadFromRealm: () => Promise<void>;
  loadWorkOrders: () => Promise<void>;
  loadWorkOrderById: (
    id: string,
    isOnline: boolean,
  ) => Promise<LocalWorkOrder | null>;
  clearSelectedItem: () => void;

  createLocal: (input: CreateWorkOrderPayload) => Promise<void>;
  updateLocal: (id: string, input: UpdateWorkOrderPayload) => Promise<void>;
  softDeleteLocal: (id: string) => Promise<void>;
  clearError: () => void;
};

function generateId() {
  return `local-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

export const useWorkOrdersStore = create<WorkOrdersStore>((set) => ({
  items: [],
  selectedItem: null,
  loading: false,
  error: null,

  clearError: () => set({ error: null }),
  clearSelectedItem: () => set({ selectedItem: null }),

  loadFromRealm: async () => {
    try {
      set({ loading: true, error: null });
      const items = await getLocalWorkOrders();
      set({ items, loading: false });
    } catch {
      set({
        loading: false,
        error: "Erro ao carregar ordens locais.",
      });
    }
  },

  loadWorkOrders: async () => {
    await useWorkOrdersStore.getState().loadFromRealm();
  },

  loadWorkOrderById: async (id, isOnline) => {
    try {
      set({ loading: true, error: null });

      const item = isOnline
        ? await fetchAndCacheWorkOrderById(id)
        : await getLocalWorkOrderById(id);

      set({ selectedItem: item, loading: false });

      return item;
    } catch (error: any) {
      set({
        selectedItem: null,
        loading: false,
        error: "Erro ao carregar ordem de serviço.",
      });
      return null;
    }
  },

  createLocal: async (input) => {
    try {
      const realm = await getRealm();
      const now = new Date().toISOString();

      realm.write(() => {
        realm.create("WorkOrder", {
          id: generateId(),
          title: input.title,
          description: input.description,
          status: input.status,
          assignedTo: input.assignedTo,
          createdAt: now,
          updatedAt: now,
          completed: input.status === "Completed",
          deleted: false,
          dirty: true,
          syncStatus: "pending",
          pendingAction: "create",
        });
      });

      const results = realm
        .objects("WorkOrder")
        .filtered("deleted == false")
        .sorted("updatedAt", true);

      set({
        items: results.map((item) => mapRealmWorkOrder(item)),
        error: null,
      });
    } catch {
      set({ error: "Erro ao criar ordem de serviço localmente." });
    }
  },

  updateLocal: async (id, input) => {
    try {
      const realm = await getRealm();
      const now = new Date().toISOString();

      realm.write(() => {
        const item = realm.objectForPrimaryKey<any>("WorkOrder", id);

        if (!item) return;

        if (input.title !== undefined) item.title = input.title;
        if (input.description !== undefined)
          item.description = input.description;
        if (input.status !== undefined) {
          item.status = input.status;
          item.completed = input.status === "Completed";
        }
        if (input.assignedTo !== undefined) item.assignedTo = input.assignedTo;

        item.updatedAt = now;
        item.dirty = true;
        item.syncStatus = "pending";

        if (item.pendingAction !== "create") {
          item.pendingAction = "update";
        }
      });

      const updatedItem = realm.objectForPrimaryKey<any>("WorkOrder", id);

      const results = realm
        .objects("WorkOrder")
        .filtered("deleted == false")
        .sorted("updatedAt", true);

      set({
        items: results.map((item) => mapRealmWorkOrder(item)),
        selectedItem: updatedItem ? mapRealmWorkOrder(updatedItem) : null,
        error: null,
      });
    } catch {
      set({ error: "Erro ao atualizar ordem de serviço localmente." });
    }
  },

  softDeleteLocal: async (id) => {
    try {
      const realm = await getRealm();
      const now = new Date().toISOString();

      realm.write(() => {
        const item = realm.objectForPrimaryKey<any>("WorkOrder", id);

        if (!item) return;

        if (item.pendingAction === "create") {
          realm.delete(item);
          return;
        }

        item.deleted = true;
        item.deletedAt = now;
        item.updatedAt = now;
        item.dirty = true;
        item.syncStatus = "pending";
        item.pendingAction = "delete";
      });

      const results = realm
        .objects("WorkOrder")
        .filtered("deleted == false")
        .sorted("updatedAt", true);

      set({
        items: results.map((item) => mapRealmWorkOrder(item)),
        selectedItem: null,
        error: null,
      });
    } catch {
      set({ error: "Erro ao remover ordem de serviço localmente." });
    }
  },
}));
